#ifndef WIN_PROPERTIES_AND_EXAMPLES_H
#define WIN_PROPERTIES_AND_EXAMPLES_H

#include"Runtime_variables.h"
#include"Win32_properties.h"

void Physical_Display_Properties();

#endif // !WIN_PROPERTIES_AND_EXAMPLES_H
