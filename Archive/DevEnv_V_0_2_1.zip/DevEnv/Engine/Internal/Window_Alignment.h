#ifndef WINDOW_ALIGNMENT_H
#define WINDOW_ALIGNMENT_H

#include"Win32_Phys_Monitor_Properties.h"
#include"Win32_properties.h"
#include"Runtime_variables.h"



#endif // !WINDOW_ALIGNMENT_H
