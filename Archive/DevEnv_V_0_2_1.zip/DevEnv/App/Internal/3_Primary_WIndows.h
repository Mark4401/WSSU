#ifndef PRIME_WINDOWS_H
#define PRIME_WINDOWS_H

void Demo_Windows();

#endif // !3_PRIME_WINDOWS_H
