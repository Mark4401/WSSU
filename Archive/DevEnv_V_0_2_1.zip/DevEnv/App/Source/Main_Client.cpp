#include <Engine.h>
#include <iostream>
#include"3_Primary_WIndows.h"

using namespace std;

int main(int argv, char* argc[])
{
    //Demo_Windows();

    Default_Systen_info();

    return 0;
}


/*

if (!GetClientRect(DEF_handle, &DEF_Handle_Dimensions)) { cerr << "GetClientRect failed: " << GetLastError() << "\n"; return; }
*/